import { Kysely, PostgresDialect } from "kysely";
import { Pool } from "pg";

interface Database {
  patients: {
    id: number;
    name: string;
    age: number;
  };
  users: {
    id: number;
    email: string;
    password: string;
  };
}

export const db = new Kysely<Database>({
  dialect: new PostgresDialect({
    pool: new Pool({
      connectionString:
        "postgresql://postgres:7ywJuMiei9tbKU85@db.hriymduheoknzibpclnt.supabase.co:5432/postgres",

      ssl: {
        rejectUnauthorized: false,
      },
      family: 4, // 👈 FORCE IPv4 (IMPORTANT)
    }),
  }),
});
